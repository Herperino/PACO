<!DOCTYPE html>

<HTML lang ="PT"> 
    <HEAD>
        
        <meta http-equiv="content-type" content="text/html; charset=utf-8" />
        
        <!-- http://getbootstrap.com/ -->
        <link href="/css/bootstrap.min.css" rel="stylesheet"/>
        
        <!-- File's CSS stylesheet -->
        <link href = "/css/style.css" rel="stylesheet"/>
        
        <!-- http://jquery.com/ -->
        <script src="/js/jquery-1.11.3.min.js"></script>

        <!-- http://getbootstrap.com/ -->
        <script src="/js/bootstrap.min.js"></script>

        <!-- https://github.com/twitter/typeahead.js/ -->
        <script src="/js/typeahead.jquery.min.js"></script>
        
        <!-- Local script files -->
        <script src="js/scripts.js"></script>
        
        <Title> PACO | Programa de Acompanhamento Farmacêutico</Title>
</HEAD>
    <BODY>
        <div id="pagetop">
            <div id = "loginform" class = "forms">
                <br><br><br><br><br><br><br>
                <script>renderLognav()
                </script>
            </div>    
            <div id= "PACO">
                <img class = "logo" alt= "logo" src ="img/paco_icon.png"/>
                <h1> PACO</h1>
                <h5> Acompanhando seu acompanhamento</h5>
            </div>
        </div>
  
  <div id = "pagemid">