<?php
    session_start();
    
    if(!empty($_SESSION['id']))
    {
        print("<h1>EM CONSTRUÇÃO</h1>");
        print("<img src = 'https://media.tenor.co/images/e530fe942ecbcb06f29b5e245f19ac39/raw' alt='spongebob'/>");
    }
    
    else
    {   
        print("<div id= 'landing'>");
        print("<h2>PACO</2h><h4>PROGRAMA DE ACOMPANHAMENTO FARMACÊUTICO</h4>");
        print("<p class = 'content'>
        O Acompanhamento Farmacoterapêutico é definido como uma prática personalizada na qual o 
        farmacêutico tem a responsabilidade de orientar o paciente, 
        além de detectar, prevenir e resolver todos os problemas relacionados com medicamentos (PRM) de uma maneira
        contínua, sistemática e documentada, em colaboração com o paciente e equipe multiprofissional. 
        O <strong>programa de acompanhamento farmacêutico</strong> é uma ferramenta elaborada por mim (Leon Nascimento)
         para realizar o acompanhamento de prescrições de pacientes internados em ambiente hospitalar");
        print (" ou ambulatorial. </p>");
        print ("</div>");
        //print("<img src ='https://media.tenor.co/images/e530fe942ecbcb06f29b5e245f19ac39/raw'/>");
    }
?>