<?php

    /**
     * This is the view file for reviewing patients lab results
     * (labref)
     */
     
?>

<?php if($P_MODE == true):?>
<h1>Em view mode</h1>
<!--THE VIEW mode allows the users to review a patient prescriptions and also edit the current prescription or add a new prescription -->
<?php else: ?>
<h1 class = 'viewtitle'>Acompanhamento laboratorial</h1>
<!--THE SELECT MODE WILL REQUEST THE PATIENT LIST VIA AJAX, RECEIVING A JSON CONTAINING THE PATIENTS. IT WILL THEN DISPLAY IT. -->
<h2>Pacientes em acompanhamento por <?php echo $_SESSION['username'] ?></h2>
<div id="patient_list">      
    <script>showPatients();
    //TODO: Render a form for a given operation
    </script>
</div>
<!--THE SELECT MODE WILL REQUEST THE PATIENT LIST VIA AJAX, RECEIVING A JSON CONTAINING THE PATIENTS. IT WILL THEN DISPLAY IT. -->

<?php endif?>