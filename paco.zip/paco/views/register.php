<?php

 //The register view goes here
 
?>
<?php if($_SERVER['REQUEST_METHOD'] == "GET"):?>
<h1>Registre-se ao PACO</h1>
<form id="register" action="register.php" method="POST" onsubmit ="validate()" >
    <p> ID:
    <input type="text"  class = "form" name="regisid" required/></p>
    <p> Senha
    <input type="password" class = "form" name="regispwd" required/></p>
    <p> Confirmar senha
    <input type="password" class = "form"  name="confirmation" required></p>
    <input type="submit" class = "form" value= "Registrar">
</form>
</?>
<?php else: ?>
    <h1> REGISTRO BEM-SUCEDIDO </h1>
<?php endif?>