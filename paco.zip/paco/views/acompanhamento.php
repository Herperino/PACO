<?php

    /**
     * This is the view file for review of prescriptions (acompanhamento).
     * It has two main modes: 
     * 
     * - A GET mode that allows the users to access their current patient list
     * - A POST mode that allows the users to review a patient prescriptions
     *  and also edit the current prescription or add a new prescription
     * 
     *  The controller will, when asking for the page, output a page mode,
     *  referenced by the variable named P_MODE. If P_MODE is true, it means
     *  the view will be rendered in a view prescription mode. 
     */
     
?>

<?php if($P_MODE == true):?>
<h1>Em view mode</h1>
<div id ="prescription_list"></div>
<!--THE VIEW mode allows the users to review a patient prescriptions and also edit the current prescription or add a new prescription -->
<?php else: ?>
<h1 class = 'viewtitle'> Acompanhamento de Prescrições</h1>
<h2>Pacientes em acompanhamento por <?php echo $_SESSION['username'] ?></h2>
<div id="patient_list">      
    <script>showPatients();
    //TODO: Render a form for a given operation
    </script>
</div>
<!--THE SELECT MODE WILL REQUEST THE PATIENT LIST VIA AJAX, RECEIVING A JSON CONTAINING THE PATIENTS. IT WILL THEN DISPLAY IT. -->
<?php endif?>