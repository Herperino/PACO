<?php

    // configuration
    require("../includes/helpers.php"); 
    
    // render portfolio
    render("landing.php");
?>
