<?php
        require("../includes/config.php");
        
        /** This file is used for the login controller */    
        
        /* Checks if the file was requested by filling the form atop the page.
        if so, starts a new session given everything is correct */
        
        if($_SERVER["REQUEST_METHOD"] == "POST")
        {
          
            // query database for user
            $users = CS50::query("SELECT * FROM PACO_users WHERE username = ?", $_POST["id"]);
            
            // if we found user, check password
            if (count($users) == 1)
            {
                // first (and only) row
                $user = $users[0];
                
                // compare hash of user's input against hash that's in database
                if (password_verify($_POST["password"], $user["userhash"]))
                {
                    // remember that user's now logged in by storing user's ID in session
                    $_SESSION["id"] = $user["id"];
                    $_SESSION["username"] = $user['username'];
    
                    // redirect to portfolio
                    redirect("index.php");
                }
                else
                {
                    render("apology.php", ['errormessage' => htmlspecialchars("Usuario ou senha errados")]);
                }
            }
            else
            {
                render("apology.php", ['errormessage' => htmlspecialchars("Usuario ou senha errados")]);
            }
            
        }
       
        else
        {
            $lines = [];
            
            // If the user isn't logged in, the site will show the log in or register form        
            if(empty($_SESSION["id"]))
            {
                /** HTML being written
                 * <h1>Entrar</h1
                 * <form class='login' action = 'login.php' method = 'POST'>
                 * <input type='text' placeholder = 'Nome' name = 'id' required>
                 * <input type = 'password' placeholder= 'Senha' name= 'password' required>
                 * <input type = 'submit' value = 'Entrar'></form>
                 * <p>ou <a href= 'register.php'> <strong>registre-se</strong> </a> </p>
                 */
                
                $lines[0] = "<h1>Entrar</h1>";
                $lines[1] ="<form class='login' action = 'login.php' method = 'POST'><input type='text' placeholder = 'Nome' name = 'id' required><input type = 'password' placeholder= 'Senha' name= 'password' required><input type = 'submit' value = 'Entrar'></form>";
                $lines[2] ="<p>ou <a href= 'register.php'> <strong>registre-se</strong> </a> </p>";
            }
            
            //else, the site will display a greeting and buttons to logout and options (TODO)
            else
            {
                /** HTML being written
                 * <h3>Bem vindo ao PACO, <strong> " . $_SESSION['username'] . "</strong></h3>"
                 * <ul class="nav nav-pills"><li><a class= 'buttons' href="logout.php">logout</a></li></ul>
                 */
                
                $lines[0] = ("<h3>Bem vindo ao PACO,<strong> " . $_SESSION['username'] . "</strong></h3>");
                $lines[1] = "<ul class='nav nav-pills'><li><a class= 'buttons' href='index.php'>Home</a></li><li><li><a class= 'buttons' href='labref.php'>Laboratorio</a></li><li><a class= 'buttons' href='acompanhamento.php'>Acompanhar</a></li><li><a class = 'buttons' href='logout.php'>Sair</a></li></ul>";
            }
            
            //However the cases given, the info will be placed in JSON format and queried in AJAX form by header
            header("Content-type: application/json");
            print(json_encode($lines, JSON_PRETTY_PRINT));
        }   
       
?>

