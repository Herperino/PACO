 
 
 /** 
  *  /paco/public/scripts.js
  * 
  *  This is the PACO JS script file.
  *  It contains functions that will work client-side to help the functioning
  *  of the whole PACO platform. The following functions are:
  * 
  *  - renderForm(Renders the login/navigation pill on the topbar)
  */

function renderLognav(){
    $.getJSON("login.php").done(function(data)
    {
        var form = $("#loginform");
        var html = '';
        
        for (var count = 0; count < data.length; count++)
        {
            html += data[count];
            
        }
        form.html(html);
    });
}

function validate(){
    
        var form = document.getElementById("register");
        var regispwd = form.regispwd.value;
        var confirmation = form.confirmation.value;
        
        if (regispwd != confirmation)
        {
            var midscreen = document.getElementById("pagemid");
            midscreen.innerHTML ="<h2 class = 'form' style= 'padding:2em; border:1px solid gray'> Wrong name or password </h2>";
            return false;
        }
}

function showPatients(){
    
    $.getJSON("patients.php").done(function(data){
    
        var form = $('#patient_list');
        var patients = data.length;
        
        var content = "<table id='patients' class='tables'>";
        
        content += "<tr><th>ID</th><th>Nome</th><th class='p_age'>Idade</th><th>Status</th><th>Ação</th></tr>";
        
        for (var count = 0; count < patients; count++)
            {
                
                content += "<tr class = 'tc'  id= 'row_" + count + "'>" ;
                content += "<td class = 'p_id' value = '" + count + "'>" + data[count].patientID + "</td>";
                content += "<td class = 'p_name' value = '" + count + "'>" + data[count].patientname + "</td>";
                content += "<td class = 'p_age' value ='" + count + "'>" + data[count].patientage + "</td>";
                content += "<td class = 'p_status' value = '" + count + "'>" + data[count].p_status+ "</td>";
                content += "<td> <select name = 'ptt_" + data[count].patientID + "'> <option  value='nada'>Selecione</option> <option value='edit'>Editar</option> <option value='changestatus'>Mudar status</option></td>";
                content += "</tr>"
                
                if (count > 10)
                    break;
            }
        
        content += "<tr></td> <td colspan = '4'></td><td><input type ='button' value= 'Adicionar Paciente' style = 'text-align:left;font-size:12px;background-color:white;height:32px;width:120px'/></tr>";
        content += "</table>";
        form.html(content);    
    });
}

function selectPatient(event){
    
    console.log(event);
    //Get the DOM object clicked
    var data = event.target.innerHTML;
    
    alert("Você quer selecionar o paciente identificado como: " + data + "?");
    
}







