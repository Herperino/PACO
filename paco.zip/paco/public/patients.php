<?php
    
    /**
     * This is the controller file for selecting patients from the file
     * The select view allows for a JSON request from acompanhamento or
     * labref to render the correct page.
     */
     
    require("../includes/config.php");
    
    $patients = []; //Array containing all the patients currently under care

    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        
        //Query the server for the patients given a user and return a JSON
        $patients = CS50::query("SELECT * FROM patients WHERE userID = ?", $_SESSION['id']);
        
        $patients = utf8_string_array_encode($patients);
        
        
        // output patients as JSON (pretty-printed for debugging convenience)
        header("Content-type: application/json; charset=UTF-8");
        print(html_entity_decode(json_encode($patients, JSON_PRETTY_PRINT)));
    }
    
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        //TODO: Get operation (Remove, Add, Change Status)
        $operation = $_POST['operation'];
        
        //TODO: Query database according to action
        if($operation == 'ADD'){
            
            //TODO: Render a 
            
        }
        else if($operation == 'REMOVE'){
                
            //TODO
            
        }
        else{    
            
            //TODO
            
        }
        
        //TODO: Return new patient list
    }
?>