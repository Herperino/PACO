<?php

    /**
     *  This is the controller file for reviewing patients prescriptions
     * (acompanhamento). The SQL database allows for up to 20 medications
     *  The fields are:userID, patient ID, patient active?, patient name, 
     *  patient age and medication (name, dose and frequency) 1-20
     */
    
    require("../includes/config.php");
    
    $prescriptions = []; //Array containing all prescriptions for a given patient
    $page_mode = false; //Defines whether the view will be displayed in Select or View mode
    
    //Get patients for the user
    /** Upon a GET request, the server will will then render the page in select mode
     *  then query the server for all the active patients under care by the user. 
     *  the query will be done via AJAX via patients.php. Once selection is done,
     *  a POST request will be done to this same controller.
     */
    
    if($_SERVER['REQUEST_METHOD'] == 'GET')
    {
       //Renders acompanhamento in view mode 
        render("acompanhamento.php", ['P_MODE' => $page_mode]);
    }
    
    
    /**A server request will trigger a POST request to the server, meaning that
     * a patient was selected. For such selection, we will grab the patient id
     * and make a request to the server for the patients prescriptions in the 
     * database.
     * 
     * Along with that, we will also display the patient's name, age and sex.
     */
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        
        $page_mode = true;
        
        $patientID = $_POST['patient'];
        
        //Display patient's last 7 days prescriptions (via render)
        //TODO
        
        render("acompanhamento.php", ['P_MODE' => $page_mode]);
    }
?>